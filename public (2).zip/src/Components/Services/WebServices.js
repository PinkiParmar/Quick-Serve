// import axios from "axios";
// class MyService
// {
//     getAPI(url)
//     {
//       return axios.get(url)
//     }
//     postAPI(url,data)
//     {
//         console.log("Post API Called...."+url)
//         console.log("Post API Data Called...."+data)
//      return axios.post(url,data)
//     }
// }

// export default new MyService