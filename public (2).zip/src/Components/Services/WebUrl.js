// export default{
//     load_category:"http://apps.codebetter.in:8082/emall/api/category/list",
//     add_category:"http://apps.codebetter.in:8082/emall/api/category/save"
// }