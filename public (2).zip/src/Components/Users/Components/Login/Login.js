import React,{useState} from "react";
import './login.css';
export default function Login()
{
    const [email,setEmail]=useState('');
    const [pass,setPass]=useState('');
       return(<>
         
        <div className="container col-lg-4 mt-5">
   
       <form >

       <div className="form-outline mb-4">
        
        <label htmlFor="email" className="form-label pull-left float-left" style={{float: "left"}}>Email</label>
        <input value={email}  className="form-control" onChange={(e)=>setEmail(e.target.value)} type="email" placeholder="youemain@gmail.com" id="email" name="email"/>
        </div>
        <div className="form-outline mb-4">
        <label htmlFor="password" className="form-label">Password</label>
        <input value={pass}  className="form-control" onChange={(e)=>setPass(e.target.value)} type="password" placeholder="*********" id="password" name="password"/>
        </div>
        <div className="row mb-4">
          <div className="col d-flex justify-content-center">
            
            <div className="form-check">
              <input className="form-check-input" type="checkbox" value="" id="form2Example31" checked />
              <label className="form-check-label" for="form2Example31"> Remember me </label>
            </div>
          </div>
      
          <div className="col">
           
            <a href="#!">Forgot password?</a>
          </div>
        </div>
        <button className="btn btn-primary btn-floating mx-1">Log In</button>
       </form>
       </div>
       
       </>
        )
    }
