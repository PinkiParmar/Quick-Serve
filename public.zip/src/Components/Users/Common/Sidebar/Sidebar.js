import React from 'react';
import{Link} from "react-router-dom"
export default function Sidebar()
{
    return (<>
                <Link className="btn shadow-none d-flex align-items-center justify-content-between bg-primary text-white w-100" data-toggle="collapse" to="#navbar-vertical" style={{height: '65px', marginTop: '-1px', padding:'0 30px;'}}>
                    <h6 className="m-0">Services</h6>
                    {/* <i className="fa fa-angle-down text-dark"></i> */}
                </Link>
                <nav className="collapse show navbar navbar-vertical navbar-light align-items-start p-0 border border-top-0 border-bottom-0" id="navbar-vertical">
                    <div className="navbar-nav w-100 overflow-hidden" style={{height:'410px'}}>
                        
                        <Link to="/electrician" className='nav-item nav-link'>Electrician</Link>
                        <Link to="/plumber" className="nav-item nav-link">Plumber</Link>
                        <Link to="/house-cleaner" className="nav-item nav-link">House cleaner</Link>
                        <Link to="/carpenter" className="nav-item nav-link">Carpenter</Link>
                    </div>
                </nav>
</>

    )
}