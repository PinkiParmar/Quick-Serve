import React from 'react';
export default function Forgrtpassword()
{
    return (
        <div>
            <h1>Forget Password</h1>
        </div>
    )
}